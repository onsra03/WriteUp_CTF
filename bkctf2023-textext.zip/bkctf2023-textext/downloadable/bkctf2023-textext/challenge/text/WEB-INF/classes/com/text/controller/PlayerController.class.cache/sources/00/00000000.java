package com.text.controller;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.Base64;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(urlPatterns = {"/get-name"})
/* loaded from: PlayerController.class */
public class PlayerController extends HttpServlet implements Serializable {
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        String player = req.getParameter("player");
        try {
            byte[] data = Base64.getDecoder().decode(player);
            InputStream is = new ByteArrayInputStream(data);
            ObjectInputStream ois = new ObjectInputStream(is);
            Object obj = ois.readObject();
            ois.close();
            Player user = (Player) obj;
            out.println("<h1> Hello: " + user.getName() + " !</h1>");
        } catch (Exception e) {
            out.println("<h1> ????????? </h1>");
        }
    }
}